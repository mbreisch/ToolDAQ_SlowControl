var searchData=
[
  ['jsonparser',['JsonParser',['../classBoostStore.html#a6380dcf800764516378adc5552f63114',1,'BoostStore::JsonParser()'],['../classStore.html#adb84e3fb286cae07f64e8186b7ab04e1',1,'Store::JsonParser()']]]
];
