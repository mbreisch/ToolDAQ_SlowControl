var searchData=
[
  ['datamodel',['DataModel',['../classDataModel.html#abff03aef2cb531142a35781bb87c3365',1,'DataModel']]],
  ['delete',['Delete',['../classBoostStore.html#a99c755b996ad99c9d610dd48ffb78f17',1,'BoostStore::Delete()'],['../classStore.html#a7fce0f8f3ec7978c5e7cd3d7053f899b',1,'Store::Delete()']]],
  ['dummytool',['DummyTool',['../classDummyTool.html#a33914471b4de346168aa92b5febb6f9c',1,'DummyTool']]]
];
