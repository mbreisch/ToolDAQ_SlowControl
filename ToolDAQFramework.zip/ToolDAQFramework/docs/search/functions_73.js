var searchData=
[
  ['save',['Save',['../classBoostStore.html#a96d434b12fa4084fa1cde1ebdf632c25',1,'BoostStore']]],
  ['serialize',['serialize',['../classSerialisableObject.html#a7c9ec7bf87b5921957768f4467c6143a',1,'SerialisableObject']]],
  ['serviceadd',['ServiceAdd',['../classServiceAdd.html#a0148b0e038f4b0dd6f12c87cdf233f69',1,'ServiceAdd']]],
  ['servicediscovery',['ServiceDiscovery',['../classServiceDiscovery.html#ab69c2cacaf5a388fac88e57f3361b576',1,'ServiceDiscovery::ServiceDiscovery(bool Send, bool Receive, int remoteport, std::string address, int multicastport, zmq::context_t *incontext, boost::uuids::uuid UUID, std::string service, int pubsec=5, int kicksec=60)'],['../classServiceDiscovery.html#a3dbd15f19345b0c9746731308e26b034',1,'ServiceDiscovery::ServiceDiscovery(std::string address, int multicastport, zmq::context_t *incontext, int kicksec=60)']]],
  ['set',['Set',['../classBoostStore.html#a94e4f0b1d996488538efc09b831cd1a6',1,'BoostStore::Set(std::string name, T in)'],['../classBoostStore.html#a198a7f41e16912b439b85523f802ad0f',1,'BoostStore::Set(std::string name, T *in, bool persist=true)'],['../classStore.html#af586739813ce18da6f5e3561d134a814',1,'Store::Set()']]]
];
