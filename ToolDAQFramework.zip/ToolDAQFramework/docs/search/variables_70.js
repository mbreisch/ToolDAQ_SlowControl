var searchData=
[
  ['pointer',['pointer',['../classPointerWrapper.html#a4866798d33eed0a9aeaa3bcda53c4a0d',1,'PointerWrapper']]],
  ['pubsec',['pubsec',['../structthread__args.html#aba650f345201e8aece9071377945cf0e',1,'thread_args']]]
];
