var searchData=
[
  ['uuid',['UUID',['../structLogging__thread__args.html#a3a7c5617b7fa5214c6da407a23266d57',1,'Logging_thread_args::UUID()'],['../structthread__args.html#a707586ba05cc2c8be29cf22769b67634',1,'thread_args::UUID()']]]
];
