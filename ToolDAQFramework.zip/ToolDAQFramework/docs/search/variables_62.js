var searchData=
[
  ['buffer',['buffer',['../classLogging.html#a9622376d4c126c163334149cabc98bcc',1,'Logging']]]
];
