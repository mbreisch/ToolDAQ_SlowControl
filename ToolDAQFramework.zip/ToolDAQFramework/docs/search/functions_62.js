var searchData=
[
  ['booststore',['BoostStore',['../classBoostStore.html#af359015c3ca44cd24fd915ec7bb008b4',1,'BoostStore::BoostStore(bool typechecking=true, int format=0)'],['../classBoostStore.html#af114bcb7df59af05e5715af756771379',1,'BoostStore::BoostStore(std::map&lt; std::string, std::string &gt; invariables)'],['../classBoostStore.html#a57b996f894624e61e8f57bf495f00c07',1,'BoostStore::BoostStore(std::map&lt; std::string, std::string &gt; invariables, std::map&lt; std::string, std::string &gt; ininfo)']]]
];
