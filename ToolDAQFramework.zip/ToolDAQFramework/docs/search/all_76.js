var searchData=
[
  ['vars',['vars',['../classDataModel.html#a4baac5fe364a7a23762d70d2c2216486',1,'DataModel']]],
  ['version',['version',['../classSerialisableObject.html#ade0071c238a09193b37a2750d2b50b18',1,'SerialisableObject']]]
];
