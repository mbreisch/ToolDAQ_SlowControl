var searchData=
[
  ['configure_20files',['Configure files',['../md_configfiles_README.html',1,'']]],
  ['configure_20files',['Configure files',['../md_configfiles_template_README.html',1,'']]]
];
