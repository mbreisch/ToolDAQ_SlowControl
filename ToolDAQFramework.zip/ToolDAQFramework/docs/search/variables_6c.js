var searchData=
[
  ['log',['Log',['../classDataModel.html#aa777da4c632e4659ee5b1447ad513458',1,'DataModel']]],
  ['logport',['logport',['../structLogging__thread__args.html#ad5ab1c21e226a694c7f813bcb3ef9002',1,'Logging_thread_args']]],
  ['logservice',['logservice',['../structLogging__thread__args.html#a5a8e255209f5c171a7fbd78f0e308087',1,'Logging_thread_args']]]
];
