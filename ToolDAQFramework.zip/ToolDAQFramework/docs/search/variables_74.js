var searchData=
[
  ['type',['type',['../classSerialisableObject.html#a893f965e41ad7f09b4066cb07fecef8e',1,'SerialisableObject']]]
];
