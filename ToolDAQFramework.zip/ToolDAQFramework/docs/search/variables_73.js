var searchData=
[
  ['serialise',['serialise',['../classSerialisableObject.html#a4635f9e80623df463bcca2c88b10fc67',1,'SerialisableObject']]],
  ['service',['service',['../structthread__args.html#a92798a7f2094db41f45ecbef0c067ca9',1,'thread_args']]]
];
